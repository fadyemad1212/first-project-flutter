import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
  home: HomePage(),
));

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        //افتكر اننا عملنا اتنين كونتينر واحد للصورة التاني للظل الاسود
        body: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/images/fady.jpeg'),
                  fit: BoxFit.cover)),
          child: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.bottomRight,
                    colors: [Colors.black, Colors.black12])),
            child: Padding(
              padding: EdgeInsets.all(20), //علشان نبعد شوية عن الجوانب
              child: Column(
                //بنستخدم الكولم علشان نحط شوية عناصر فوق بعض
                crossAxisAlignment:
                CrossAxisAlignment.start, //ده المحور الافقي في الاول
                mainAxisAlignment: MainAxisAlignment
                    .end, //ده المحور الاساسي للعمود و مظبوط في الاخر
                children: <Widget>[
                  Text(
                    "Drugs  ",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 40),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: <Widget>[
                      Text(
                        "Stop smoking ",
                        style: TextStyle(color: Colors.green ,fontSize: 15,fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: 50,
                      ),
                      Text(
                        "",
                        style: TextStyle(color: Colors.green, fontSize: 15,fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  Text(
                    " ",
                    style: TextStyle(color: Colors.white, height: 1.4,fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 20,
                  ),
//follow
                  Align(
                    child: Card(
                      shape: StadiumBorder(),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [Text("Follow ")],

                        ),
                      ),
                      color: Colors.red,
                    ),
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
